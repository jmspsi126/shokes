@extends('wiki.app')
@section('contentPane')



<div class="container-fluid">
	<div class="col-md-12">
			
		<div style = "height:350px;background-color:#eee;padding:3%;margin-top:5%">	
			<p>
				Documentation Menu
				<span class="pull-right">
					<a class="btn btn-success btn-xs" href={{url("/".$name."/wiki/create")}}><i class="glyphicon glyphicon-plus"></i></a>
				</span>
			</p>
			<hr style = "border-top:2px solid #EAE4E4;margin-top:10px">
			<ul>
				@foreach($pages as $page)
				<li><a href={{url("/".$name."/wiki/".$page->id)}}>{{ $page->title }}</a></li>
				@endforeach
			</ul>
		</div>

	</div>
</div>
<div class="container-fluid footer">
	<div class="col-sm-3 col-md-2"></div>
</div>

<script>
	function goBack(){
		window.history.back();
	}
</script>
@endsection
