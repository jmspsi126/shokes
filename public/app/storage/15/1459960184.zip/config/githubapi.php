<?php
/**
 * Created by PhpStorm.
 * User: bento
 * Date: 4/5/16
 * Time: 4:28 PM
 */

return [

    /*
    |--------------------------------------------------------------------------
    | Gihut Personal Token
    |--------------------------------------------------------------------------
    |
    | Set these value for using personal token
    |
    */

    'username'     	=> 'ShokseTest',
    'token' 	    => 'e814bdd9ae716d62196df1ae9bff1f6a413ddf63',

];