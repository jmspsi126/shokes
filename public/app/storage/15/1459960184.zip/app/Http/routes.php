<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

// Display the sample tester UI.
Route::get('/', function () {
    return view('welcome');
});

/*
 * Testing the config file can be called, meaning library has been installed successfully
 */
Route::get('/test', function () {
    return GHAPI::test();
});

/*
 *  ======================= TEST REPOSITORY AREA =======================
 */

/*
 * List all repo for the user that set in config file. Can be pass some parameters but optionals
 * First parameters is parameters, null mean use the default values.
 * Second parameters is return format in json, optional and default value is false
 */
Route::get('repo/all', function() {
//   return GHAPI::ListRepository(null, true);
    return GHAPI::repo()->lists();
});

/*
 * List branches in given repo name call "test"
 */
Route::get('repo/branches', function() {
    return GHAPI::branch()->lists('test');
});

/*
 * Get branch detail in given repo name call "test"
 */
Route::get('repo/branch/1.02_add_list_item_forecast_layout', function() {
    return GHAPI::branch()->get('test', '1.02_add_list_item_forecast_layout' );
});

/*
 * Get ROOT contents of a repo name call "test" from a default branch
 * For test repo, default branch is 1.01_hello_world
 */
Route::get('repo/content/root', function() {
    $params = array(
        'RepoName'  => 'test',
        'StartPath' => '/'
    );
    return GHAPI::content()->get($params);
});

/*
 * Get recursive content of start path 'app' in default branch for 2 levels
 * First level is content of /app folder as starting path
 * Secodng level is content of each folder inside /app folder
 * For test repo, default branch is 1.01_hello_world
 *
 * For unlimited recursive just remove the second parameter, default value -1 is unlimited recursive
 * Example : return json_encode(GHAPI::GetRecursiveContents($params));
 */
Route::get('repo/content/recursive', function() {
    $params = array(
        'RepoName'  => 'test',
        'StartPath' => '/'
    );
    return json_encode(GHAPI::content()->recursive($params, 2));
});

/*
 * Get ROOT contents of a repo name call "test" from a selected branch 1.02_add_list_item_forecast_layout
 */
Route::get('repo/content/branch', function() {
    $params = array(
        'RepoName'  => 'test',
        'StartPath' => '/',
        'Ref'       => '1.02_add_list_item_forecast_layout'
    );
    return GHAPI::content()->get($params);
});

/*
 * Get contents of README.md file as value of StartPath of a repo name call "test"
 */
Route::get('repo/content/file', function() {
    $params = array(
        'RepoName'  => 'test',
        'StartPath' => 'README.md'
    );
    return GHAPI::content()->get($params);
});

/*
 * Get contents of README.md file as value of StartPath in branch call 1.02_add_list_item_forecast_layout
 * and a repo name call "test"
 */
Route::get('repo/content/file/branch', function() {
    $params = array(
        'RepoName'  => 'test',
        'StartPath' => 'README.md',
        'Ref'       => '1.02_add_list_item_forecast_layout'
    );
    return GHAPI::content()->get($params);
});


/*
 * ======================= DEVELOPER REPOSITORY AREA =======================
 */

/*
 * Create new repo call "developer" in array. The key must exist in array is name of repo.
 * First parameters is parameters, null mean use the default values.
 * Second parameters is return format in array, optional and default value is false
 */
Route::get('repo/create', function() {
    $params = array(
        'name'      => 'developer',
        'auto_init' => true
    );

    return GHAPI::repo()->create($params);
    //  or with this code return GHAPI::repo()->create(array('name' => 'developer'));
});

/*
 * Delete new repo call "developer"
 */
Route::get('repo/delete', function() {
    return GHAPI::repo()->delete('developer');
});

/*
 * List branches in given repo name call "developer"
 */
Route::get('repo/branches/developer', function() {
    return GHAPI::branch()->lists('developer');
});


/*
 * Create new branch caled 'develop' from master in a given repo name call "developer"
 */
Route::get('repo/branch/create/develop', function() {
    $params = array(
        'RepoName'     => 'developer',
        'BranchRefs'   => 'master',
        'BranchName'   => 'develop'
    );
    return GHAPI::branch()->create($params);
});

/*
 * Delete branch caled 'develop' from master in a given repo name call "developer"
 */
Route::get('repo/branch/delete/develop', function() {
    $params = array(
        'RepoName'     => 'developer',
        'BranchName'   => 'develop'
    );
    return GHAPI::branch()->delete($params);
});

