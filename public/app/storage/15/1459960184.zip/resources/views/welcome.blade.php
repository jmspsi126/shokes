<!DOCTYPE html>
<html>
    <head>
        <title>Laravel</title>
        <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
        <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    </head>
    <body>
        <img src="{{ asset('img/circleloadinganimation.gif') }}"/>
        <div class="container">
            <h2>Example using Github API Wrapper</h2>
            <hr />
            <div class="col-md-3">
                <button class="btn btn-default btn-sm" id="btnAllRepo">List all repo in json</button>
                <label for="test" class="control-label">Repo: Test</label>
                <button class="btn btn-default btn-sm" id="btnListBranches">List of branches</button>
                <button class="btn btn-default btn-sm" id="btnGetBranch">Get branch</button>
                <button class="btn btn-default btn-sm" id="btnGetContentRoot">Get content of default branch</button>
                <button class="btn btn-default btn-sm" id="btnGetContentRecurse">Get recursive content on branch</button>
                <button class="btn btn-default btn-sm" id="btnGetContentBranch">Get content of selected branch</button>
                <button class="btn btn-default btn-sm" id="btnGetContentFile">Get file on master branch</button>
                <button class="btn btn-default btn-sm" id="btnGetFileDevelop">Get file on develop branch</button>
                <label for="develop" class="control-label">Repo: Developer</label>
                <button class="btn btn-default btn-sm" id="btnCreateRepo">Create repository</button>
                <button class="btn btn-default btn-sm" id="btnDeleteRepo">Delete repository</button>
                <button class="btn btn-default btn-sm" id="btnListBranchDev">List of branches</button>
                <button class="btn btn-default btn-sm" id="btnCreateBranch">Create branch</button>
                <button class="btn btn-default btn-sm" id="btnDeleteBranch">Delete branch</button>
            </div>
            <div class="col-md-9">
                <textarea class="form-control" id="result"></textarea>
            </div>
        </div>
        <script src="{{ asset('js/jquery.min.js') }}"></script>
        <script src="{{ asset('js/script.js') }}"></script>
    </body>
</html>
