<?php
/**
 * Created by PhpStorm.
 * User: bento
 * Date: 4/6/16
 * Time: 10:35 PM
 */

namespace Shokse\GithubAPI;

class Branch extends AbstractGithub
{

    /**
     * @param $repo
     * @param bool $protected
     * @param bool $json
     * @return mixed
     */
    public function lists($repo, $protected = false, $json = false) {
        $url = $this->api_url . "/repos/$this->username/$repo/branches";
        if ($protected) {
            $url .= http_build_query($protected);
        }
        return parent::retrieve($url, $json);
    }

    /**
     * @param $params
     * @param bool $json
     * @return mixed
     */
    public function create($params, $json = false) {
        if ( array_key_exists('RepoName', $params) && array_key_exists('BranchName', $params) && array_key_exists('BranchRefs', $params) ) {
            $repo_name      = $params['RepoName'];
            $branch_name    = $params['BranchName'];
            $branch_refs    = $params['BranchRefs'];

            $url = $this->api_url . "/repos/$this->username/$repo_name/git/refs";
            $sha = $this->get($repo_name, $branch_refs)['commit']['sha'];
            $data = array(
                "ref" => "refs/heads/$branch_name",
                "sha" => $sha
            );
            return parent::post($url, $json, json_encode($data));
        }
    }

    /**
     * @param $params
     * @return mixed
     */
    public function delete($params) {
        if ( array_key_exists('RepoName', $params) && array_key_exists('BranchName', $params) ) {
            $repo_name      = $params['RepoName'];
            $branch_name    = $params['BranchName'];

            $url = $this->api_url . "/repos/$this->username/$repo_name/git/refs/heads/$branch_name";
            $result = parent::erase($url);
            if ( $result == '')
                return json_encode(array("message" => "Branch '$branch_name' has been deleted."));
            else
                return $result;
        }
    }

    /**
     * @param $repo
     * @param $branch
     * @param bool $json
     * @return mixed
     */
    public function get($repo, $branch, $json = false) {
        $url = $this->api_url . "/repos/$this->username/$repo/branches/$branch";
        return parent::retrieve($url, $json);
    }

}