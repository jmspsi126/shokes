<?php
/**
 * Created by PhpStorm.
 * User: bento
 * Date: 4/6/16
 * Time: 10:35 PM
 */

namespace Shokse\GithubAPI;

class Repository extends AbstractGithub
{
    
    public function lists($params = null, $json = false) {
        $url = $this->api_url . "/user/repos?";
        if ($params) {
            $url .= http_build_query($params);
        }
        return parent::retrieve($url, $json);
    }

    /**
     * Create new repository of the user
     * Check https://developer.github.com/v3/repos/#create
     * @param $params
     * @param bool $json
     * @return mixed
     */
    public function create($params, $json = false) {
        if (array_key_exists('name', $params)) {
            $url = $this->api_url . "/user/repos";
            return parent::post($url, $json, json_encode($params));
        }
    }

    /**
     * @param string $repo name of repository to delete
     * @return mixed
     */
    public function delete($repo) {
        $url = $this->api_url . "/repos/$this->username/$repo";
        $result = parent::erase($url);
        if ( $result == '')
            return json_encode(array("message" => "Repo '$repo' has been deleted."));
        else
            return $result;
    }

}