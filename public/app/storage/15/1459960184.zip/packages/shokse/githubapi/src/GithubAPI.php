<?php
/**
 * Created by PhpStorm.
 * User: bento
 * Date: 4/5/16
 * Time: 4:19 PM
 */

namespace Shokse\GithubAPI;

use Config;

class GithubAPI
{

    public $config = array(
        'username'  => '',
        'token'     => ''
    );

    public function __construct(array $config = array())
    {
        $this->configure($config);
        $this->username = $this->config['username'];
        $this->token    = $this->config['token'];
    }

    /**
     * Overrides configuration settings
     *
     * @param array $config
     * @return $this
     */
    public function configure(array $config = array())
    {
        $this->config = array_replace($this->config, $config);
        return $this;
    }

    /**
     * For testing purpose only
     */
    public function test() {
        echo "username : " . $this->username . "<br />";
        echo "token : " . $this->token;
    }

    public function repo() {
        return new Repository($this->config);
    }

    public function branch() {
        return new Branch($this->config);
    }

    public function content() {
        return new Content($this->config);
    }

}