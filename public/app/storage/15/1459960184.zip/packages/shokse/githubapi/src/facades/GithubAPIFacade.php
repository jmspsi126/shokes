<?php
/**
 * Created by PhpStorm.
 * User: bento
 * Date: 4/5/16
 * Time: 4:26 PM
 */

namespace Shokse\GithubAPI\Facades;

use Illuminate\Support\Facades\Facade;

class GithubAPIFacade extends Facade {
    protected static function getFacadeAccessor() { return 'githubapi'; }
}