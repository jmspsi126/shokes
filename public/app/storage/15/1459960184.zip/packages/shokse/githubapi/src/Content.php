<?php
/**
 * Created by PhpStorm.
 * User: bento
 * Date: 4/6/16
 * Time: 11:08 PM
 */

namespace Shokse\GithubAPI;

class Content extends AbstractGithub
{

    /**
     * @param $params
     * @param bool $json
     * @return mixed
     */
    public function get($params, $json = false) {
        if ( array_key_exists('RepoName', $params) && array_key_exists('StartPath', $params) ) {
            $repo = $params['RepoName'];

            if ($params['StartPath'] == '/') {
                $path = '?path=/';
                $ref = array_key_exists('Ref', $params) ? '&ref='.$params['Ref'] : null;
            } else {
                $path = '/'.$params['StartPath'];
                $ref = array_key_exists('Ref', $params) ? '?ref='.$params['Ref'] : null;
            }

            $url = $this->api_url . "/repos/$this->username/$repo/contents$path$ref";
            return $result = parent::retrieve($url, $json);
        } else {
            return json_encode(array('message' => 'Please provide RepoName and StartPath in arrays parameter $params'));
        }
    }

    /**
     * @param $params
     * @param $num
     * @param array $result
     * @return array
     */
    public function recursive($params, $num = -1, &$result = array()) {
        $contents = $this->get($params);
        if ($num != -1) $num--;
        foreach ($contents as $item) {
            if (($item["type"] == "dir") && $num != 0) {
                $params['StartPath'] = $item['path'];
                $result[] = $item;
                $this->recursive($params, $num, $result);
            } else {
                /*
                 * $result[] = $item;
                 * If no need content of file as a result
                 * uncomment above line and comment these 2 lines below
                 */
                 $params['StartPath'] = $item['path'];
                 $result[] = $this->get($params);
            }
        }
        return $result;
    }
    
}