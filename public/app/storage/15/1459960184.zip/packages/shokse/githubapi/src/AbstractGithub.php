<?php
/**
 * Created by PhpStorm.
 * User: bento
 * Date: 4/6/16
 * Time: 10:33 PM
 */

namespace Shokse\GithubAPI;

class AbstractGithub 
{

    public $config = array(
        'username'  => '',
        'token'     => ''
    );

    protected $api_url    = 'https://api.github.com';
    protected $username   = '';
    protected $token      = '';
    protected $auth_str   = '';

    public function __construct(array $config = array())
    {
        $this->configure($config);
        $this->username = $this->config['username'];
        $this->token    = $this->config['token'];
        $this->auth_str = $this->username . ":" . $this->token;
    }

    /**
     * Overrides configuration settings
     *
     * @param array $config
     * @return $this
     */
    public function configure(array $config = array())
    {
        $this->config = array_replace($this->config, $config);
        return $this;
    }

    /**
     * Get method helper
     * @param $url
     * @param bool $json
     * @return mixed
     */
    protected function retrieve($url, $json = false) {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_USERAGENT, 0);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_USERPWD, "$this->auth_str");
        $result = curl_exec($curl);
        curl_close($curl);

        if ($json) {
            return $result;
        } else {
            return json_decode($result, true);
        }
    }

    /**
     * @param $url
     * @param bool $json
     * @param string $data
     * @return mixed
     */
    protected function post($url, $json = false, $data = '') {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_USERAGENT, 0);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_USERPWD, "$this->auth_str");
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array("Content-Type: application/json"));
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        $result = curl_exec($curl);
        curl_close($curl);
        if ($json) {
            return $result;
        } else {
            return json_decode($result, true);
        }
    }

    /**
     * @param $url
     * @return mixed
     */
    protected function erase($url) {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_USERAGENT, 0);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_USERPWD, "$this->auth_str");
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'DELETE');
        $result = curl_exec($curl);
        curl_close($curl);
        return $result;
    }
}

