$(function() {

    $("button").click(function() {
        $("img").css('display', 'block');
        var url = '';

        var desc = [
            "",
            ''
        ]

        if (this.id == 'btnAllRepo')            url = '/repo/all';
        if (this.id == 'btnListBranches')       url = '/repo/branches';
        if (this.id == 'btnGetBranch')          url = '/repo/branch/1.02_add_list_item_forecast_layout';
        if (this.id == 'btnGetContentRoot')     url = '/repo/content/root';
        if (this.id == "btnGetContentRecurse")  url = '/repo/content/recursive';
        if (this.id == 'btnGetContentBranch')   url = '/repo/content/branch';
        if (this.id == 'btnGetContentFile')     url = '/repo/content/file';
        if (this.id == 'btnGetFileDevelop')     url = '/repo/content/file/branch';
        if (this.id == 'btnCreateRepo')         url = '/repo/create';
        if (this.id == 'btnDeleteRepo')         url = '/repo/delete';
        if (this.id == 'btnListBranchDev')      url = '/repo/branches/developer';
        if (this.id == 'btnCreateBranch')       url = '/repo/branch/create/develop';
        if (this.id == 'btnDeleteBranch')       url = '/repo/branch/delete/develop';

        console.log(url);
        $.ajax({
                url: url,
                type: 'GET',
                dataType: 'json',
            })
            .done(function(data) {
                $("#description").val(desc['btnAllRepo']);
                $("#result").val(JSON.stringify(data, null, '\t'));
            })
            .fail(function(data, b, c) {
                console.log(data.responseText);
            })
            .always(function() {
                $("img").css('display', 'none');
            })
    })

})