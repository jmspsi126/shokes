$(function() {

    $("button").click(function() {
        $("img").css('display', 'block');
        var url = '';

        if (this.id == 'btnAllRepo') url = '/repo/all';
        if (this.id == 'btnCreateRepo') url = '/repo/create';
        if (this.id == 'btnDeleteRepo') url = '/repo/delete';

        console.log(url);
        $.ajax({
                url: url,
                type: 'GET',
                dataType: 'json',
            })
            .done(function(data) {
                $("#result").val(JSON.stringify(data, null, '\t'));
            })
            .fail(function(data, b, c) {
                console.log(data);
            })
            .always(function() {
                $("img").css('display', 'none');
            })
    })

})