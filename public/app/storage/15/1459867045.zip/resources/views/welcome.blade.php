<!DOCTYPE html>
<html>
    <head>
        <title>Laravel</title>
        <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
        <link rel="stylesheet" href="{{ asset('css/style.css') }}">
    </head>
    <body>
        <img src="{{ asset('img/circleloadinganimation.gif') }}"/>
        <div class="container">
            <h1>Example using Github API Wrapper</h1>
            <hr />
            <div class="col-md-2">
                <button class="btn btn-default" id="btnAllRepo">List Repo in Json</button>
                <button class="btn btn-default" id="btnCreateRepo">Create Repository</button>
                <button class="btn btn-default" id="btnDeleteRepo">Delete Repository</button>
            </div>
            <div class="col-md-10">
                <textarea class="form-control" id="result"></textarea>
            </div>
        </div>
        <script src="{{ asset('js/jquery.min.js') }}"></script>
        <script src="{{ asset('js/script.js') }}"></script>
    </body>
</html>
