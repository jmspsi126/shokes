<?php
/**
 * Created by PhpStorm.
 * User: bento
 * Date: 4/5/16
 * Time: 4:19 PM
 */

namespace Shokse\GithubAPI;

use Config;

class GithubAPI
{

    public $config = array(
        'username'  => '',
        'token'     => ''
    );

    private $api_url    = 'https://api.github.com';
    private $username   = '';
    private $token      = '';
    private $auth_str   = '';

    public function __construct(array $config = array())
    {
        $this->configure($config);
        $this->username = $this->config['username'];
        $this->token    = $this->config['token'];
        $this->auth_str = $this->username . ":" . $this->token;
    }

    /**
     * Overrides configuration settings
     *
     * @param array $config
     * @return $this
     */
    public function configure(array $config = array())
    {
        $this->config = array_replace($this->config, $config);
        return $this;
    }

    /**
     * For testing purpose only
     */
    public function test() {
        echo "username : " . $this->username . "<br />";
        echo "token : " . $this->token;
    }

    /**
     * List all repository of the user
     * @param bool $json. True if return in json, false will return in array
     * @param string $visibility can be one of all, public, or private. Default: all
     * @param string $sort can be one of created, updated, pushed, full_name. Default: full_name
     * @param string $direction can be one of asc or desc. Default: when using full_name: asc; otherwise desc
     * @return mixed
     * @internal param string $type
     */
    public function ListRepository($json = false, $visibility = 'all', $sort = 'full_name', $direction = 'desc') {
        $params = array(
            'visibility'    => $visibility,
            'sort'          => $sort,
            'direction'     => $direction
        );
        $url = $this->api_url . "/user/repos?" . http_build_query($params);
        return $this->get($url);
    }

    /**
     * @param $name
     * @param bool $json
     * @param string $description
     * @param bool $private
     * @param bool $auto_init
     * @return mixed
     */
    public function CreateRepository($name, $json = false, $description = '', $private = false, $auto_init = false) {
        $params = array(
            'name'          => $name,
            'description'   => $description,
            'private'       => $private,
            'auto_init'     => $auto_init
        );
        $url = $this->api_url . "/user/repos";
        return $this->post($url, $json, json_encode($params));
    }

    /**
     * @param $repo
     * @return mixed
     */
    public function DeleteRepository($repo) {
        $url = $this->api_url . "/repos/$this->username/$repo";
        $this->delete($url);
        return json_encode("Repo has been deleted");
    }

    // ================================= Helper Methods ==================================

    /**
     * Get method helper
     * @param $url
     * @param bool $json
     * @return mixed
     */
    private function get($url, $json = false) {
        $result = shell_exec("curl -u $this->auth_str $url");
        if ($json) {
            return $result;
        } else {
            return json_decode($result, true);
        }
    }

    /**
     * @param $url
     * @param bool $json
     * @param string $data
     * @return mixed
     */
    private function post($url, $json = false, $data = '') {
        $result = shell_exec("curl -H \"Content-Type: application/json\" -u $this->auth_str -d '$data' $url");
        if ($json) {
            return $result;
        } else {
            return json_decode($result, true);
        }
    }

    /**
     * @param $url
     * @return mixed
     */
    private function delete($url) {
        $result = shell_exec("curl -H 'Authorization: token $this->token'  -X DELETE $url");
        return $result;
    }

}