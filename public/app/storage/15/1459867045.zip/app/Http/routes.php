<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

// Display the sample tester UI.
Route::get('/', function () {
    return view('welcome');
});

// Testing the config file can be called, meaning library has been installed successfully
Route::get('/test', function () {
    return GHAPI::test();
});

// List all repo for the user that set in config file
Route::get('repo/all', function() {
   return GHAPI::ListRepository(true);
});

// Create new repo call "developer".
Route::get('repo/create', function() {
    return GHAPI::CreateRepository('developer');
});

// Delete new repo call "developer"
Route::get('repo/delete', function() {
    return GHAPI::DeleteRepository('developer');
});