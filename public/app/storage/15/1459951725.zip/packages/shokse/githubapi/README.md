# Github API Wrapper for Laravel

## Installation


- Extract to root of laravel project so it will have following structure

```
	root
	----packages/
		----shokse/
			----githubapi/
				----src/
					---- config/
						---- config.php
					---- facades/
						---- GithubAPIFacade.php
					---- GithubAPI.php
					---- GithubAPIServiceProvider.php
				----composer.json
				----README
```

- Open app.php in config folder and set this line to 'provider'

	```Shokse\GithubAPI\GithubAPIServiceProvider::class,```
	
- Also setup facade to 'aliases' part

	```'GHAPI'     => Shokse\GithubAPI\Facades\GithubAPIFacade::class,```

- Set autoload in composer.json in root folder

```
        "psr-4": {
            "App\\": "app/",
            "Shokse\\GithubAPI\\": "packages/shokse/githubapi/src/"
        }
```

- Copy config.php file in packages folder to root/config folder, and rename it as ```githubapi.php```

- Finally run this command to detect the new library classes

	```composer dump-autoload```

## Config

It use the simple configuration array values :

```
    'username'     	=> 'ShokseTest',
    'token' 	    => 'e814bdd9ae716d62196df1ae9bff1f6a413ddf63',

```


## How to use

For the initial testing that the package is working, you can test and change the route of fresh laravel installation like this. 

```
	Route::get('/test', function () {
    	return \GHAPI::test();
	});
```

This should be display in browser

```
username : ShokseTest
token : e814bdd9ae716d62196df1ae9bff1f6a413ddf63
```

##Example

No controller or model created for this example. Just a modify a routes file to get the path and call GithubAPI method in a closure. When accessing root project in browser, it will display simple UI with some button. Let's test with this scenario :

1. Click button "List Repository". It will display result  in textarea
2. Click button "Create Repository". This will display result with some info of the created repo
3. Click button "Create Reponsitory" again. Will display error message.
4. Click button "Delete", It will not return anything from Github using personal token, so the library create a message for it.

Below is corresponding code in routes file.

```

// Display the sample tester UI.
Route::get('/', function () {
    return view('welcome');
});

// Testing the config file can be called, meaning library has been installed successfully
Route::get('/test', function () {
    return GHAPI::test();
});

// List all repo for the user that set in config file
Route::get('repo/all', function() {
   return GHAPI::ListRepository(true);
});

// Create new repo call "developer". 
Route::get('repo/create', function() {
    return GHAPI::CreateRepository('developer');
});

// Delete new repo call "developer"
Route::get('repo/delete', function() {
    return GHAPI::DeleteRepository('developer');
});

```


## Recursive Method Notes

Recursive content will use this method below. Please note about files, that you can change from retrieving listing of files to listing files with contents. 

The concern perhaps rate limit for the request, because when retrieving files with content will create new request for each files.

Just comment this line if need retrieve content of file when using recursive method :

```
$result[] = $item;
```

And uncomment these 2 lines :

```
$params['StartPath'] = $item['path'];
$result[] = $this->GetContents($params);
```

Below is code of the method.

```
public function GetRecursiveContents($params, $num = -1, &$result = array()) {
        $contents = $this->GetContents($params);
        if ($num != -1) $num--;
        foreach ($contents as $item) {
            if (($item["type"] == "dir") && $num != 0) {
                $params['StartPath'] = $item['path'];
                $result[] = $item;
                $this->GetRecursiveContents($params, $num, $result);
            } else {
                $result[] = $item;

                /*
                 * If need content of file as a result
                 * comment above line and use these 2 lines below
                 *
                 * $params['StartPath'] = $item['path'];
                 * $result[] = $this->GetContents($params);
                 */
            }
        }
        return $result;
    }
```

