<?php
/**
 * Created by PhpStorm.
 * User: bento
 * Date: 4/5/16
 * Time: 4:19 PM
 */

namespace Shokse\GithubAPI;

use Config;

class GithubAPI
{

    public $config = array(
        'username'  => '',
        'token'     => ''
    );

    private $api_url    = 'https://api.github.com';
    private $username   = '';
    private $token      = '';
    private $auth_str   = '';

    public function __construct(array $config = array())
    {
        $this->configure($config);
        $this->username = $this->config['username'];
        $this->token    = $this->config['token'];
        $this->auth_str = $this->username . ":" . $this->token;
    }

    /**
     * Overrides configuration settings
     *
     * @param array $config
     * @return $this
     */
    public function configure(array $config = array())
    {
        $this->config = array_replace($this->config, $config);
        return $this;
    }

    /**
     * For testing purpose only
     */
    public function test() {
        echo "username : " . $this->username . "<br />";
        echo "token : " . $this->token;
    }

    /**
     * List all repository of the user
     * Check https://developer.github.com/v3/repos/#list-your-repositories
     * @param null $params array of parameters.
     * @param bool $json . True if return in json, false will return in array
     * @return mixed
     */
    public function ListRepository($params = null, $json = false) {
        $url = $this->api_url . "/user/repos?";
        if ($params) {
            $url .= http_build_query($params);
        }
        return $this->get($url, $json);
    }

    /**
     * Create new repository of the user
     * Check https://developer.github.com/v3/repos/#create
     * @param $params
     * @param bool $json
     * @return mixed
     */
    public function CreateRepository($params, $json = false) {
        if (array_key_exists('name', $params)) {
            $url = $this->api_url . "/user/repos";
            return $this->post($url, $json, json_encode($params));
        }
    }

    /**
     * @param $repo
     * @return mixed
     */
    public function DeleteRepository($repo) {
        $url = $this->api_url . "/repos/$this->username/$repo";
        $result = $this->delete($url);
        if ( $result == '')
            return json_encode(array("message" => "Repo '$repo' has been deleted."));
        else
            return $result;
    }

    /**
     * @param $repo. Repository name
     * @param bool $protected. True will return only protected branches
     * @param bool $json
     * @return mixed
     */
    public function ListBranches($repo, $protected = false, $json = false) {
        $url = $this->api_url . "/repos/$this->username/$repo/branches";
        if ($protected) {
            $url .= http_build_query($protected);
        }
        return $this->get($url, $json);
    }

    /**
     * @param $params
     * @param bool $json
     * @return mixed
     */
    public function CreateBranch($params, $json = false) {
        if ( array_key_exists('RepoName', $params) && array_key_exists('BranchName', $params) && array_key_exists('BranchRefs', $params) ) {
            $repo_name      = $params['RepoName'];
            $branch_name    = $params['BranchName'];
            $branch_refs    = $params['BranchRefs'];

            $url = $this->api_url . "/repos/$this->username/$repo_name/git/refs";
            $sha = $this->GetBranch($repo_name, $branch_refs)['commit']['sha'];
            $data = array(
                "ref" => "refs/heads/$branch_name",
                "sha" => $sha
            );
            return $this->post($url, $json, json_encode($data));
        }
    }

    public function DeleteBranch($params) {
        if ( array_key_exists('RepoName', $params) && array_key_exists('BranchName', $params) ) {
            $repo_name      = $params['RepoName'];
            $branch_name    = $params['BranchName'];

            $url = $this->api_url . "/repos/$this->username/$repo_name/git/refs/heads/$branch_name";
            $result = $this->delete($url);
            if ( $result == '')
                return json_encode(array("message" => "Branch '$branch_name' has been deleted."));
            else
                return $result;
        }
    }

    /**
     * @param $repo
     * @param $branch
     * @param bool $json
     * @return mixed
     */
    public function GetBranch($repo, $branch, $json = false) {
        $url = $this->api_url . "/repos/$this->username/$repo/branches/$branch";
        return $this->get($url, $json);
    }

    /**
     * @param $params
     * @param bool $json
     * @return mixed
     */
    public function GetContents($params, $json = false) {
        if ( array_key_exists('RepoName', $params) && array_key_exists('StartPath', $params) ) {
            $repo = $params['RepoName'];

            if ($params['StartPath'] == '/') {
                $path = '?path=/';
                $ref = array_key_exists('Ref', $params) ? '&ref='.$params['Ref'] : null;
            } else {
                $path = '/'.$params['StartPath'];
                $ref = array_key_exists('Ref', $params) ? '?ref='.$params['Ref'] : null;
            }

            $url = $this->api_url . "/repos/$this->username/$repo/contents$path$ref";
            return $result = $this->get($url, $json);
        } else {
            return json_encode(array('message' => 'Please provide RepoName and StartPath in arrays parameter $params'));
        }
    }

    /**
     * @param $params
     * @param $num
     * @param array $result
     * @return array
     */
    public function GetRecursiveContents($params, $num = -1, &$result = array()) {
        $contents = $this->GetContents($params);
        if ($num != -1) $num--;
        foreach ($contents as $item) {
            if (($item["type"] == "dir") && $num != 0) {
                $params['StartPath'] = $item['path'];
                $result[] = $item;
                $this->GetRecursiveContents($params, $num, $result);
            } else {
                $result[] = $item;

                /*
                 * If need content of file as a result
                 * comment above line and use these 2 lines below
                 *
                 * $params['StartPath'] = $item['path'];
                 * $result[] = $this->GetContents($params);
                 */
            }
        }
        return $result;
    }

    /**
     * @param $repo
     * @param bool $json
     * @return mixed
     */
    public function ListCommit($repo, $json = false) {
        $url = $this->api_url . "/repos/$this->username/$repo/commits";
        return $this->get($url, $json);
    }

    // ================================= Helper Methods ==================================

    /**
     * Get method helper
     * @param $url
     * @param bool $json
     * @return mixed
     */
    private function get($url, $json = false) {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_USERAGENT, 0);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_USERPWD, "$this->auth_str");
        $result = curl_exec($curl);
        curl_close($curl);

//        $result = shell_exec("curl -u $this->auth_str $url");
        if ($json) {
            return $result;
        } else {
            return json_decode($result, true);
        }
    }

    /**
     * @param $url
     * @param bool $json
     * @param string $data
     * @return mixed
     */
    private function post($url, $json = false, $data = '') {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_USERAGENT, 0);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_USERPWD, "$this->auth_str");
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array("Content-Type: application/json"));
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        $result = curl_exec($curl);
        curl_close($curl);
//        $result = shell_exec("curl -H \"Content-Type: application/json\" -u $this->auth_str -d '$data' $url");
        if ($json) {
            return $result;
        } else {
            return json_decode($result, true);
        }
    }

    /**
     * @param $url
     * @return mixed
     */
    private function delete($url) {
//        return shell_exec("curl -H 'Authorization: token $this->token'  -X DELETE $url");
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_USERAGENT, 0);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_USERPWD, "$this->auth_str");
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'DELETE');
        $result = curl_exec($curl);
        curl_close($curl);
        return $result;
    }

}