<?php
namespace Shokse\ProjectApi\Logger;
/**
 * Created by PhpStorm.
 * User: sishir
 * Date: 4/6/16
 * Time: 7:00 PM
 */
interface LoggerInterface
{
    public function log($message);
}